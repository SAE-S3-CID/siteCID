#include "iris_outils.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <fichier_iris>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "rb");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", argv[1]);
        return 2;
    }

    float tab[150];
    if (fread(tab, sizeof(float), 150, file) != 150) {
        printf("Erreur lors de la lecture du fichier %s\n", argv[1]);
        fclose(file);
        return 2;
    }

    fclose(file);

    float moyenne[3];
    float min[3];
    float max[3];

    for (int i = 0; i < 3; i++) {
        moyenne[i] = calcul_moyenne(&tab[i * 50], 50);
        min[i] = calcul_min(&tab[i * 50], 50);
        max[i] = calcul_max(&tab[i * 50], 50);
    }

    affiche_resultats(moyenne, min, max);

    return 0;
}
