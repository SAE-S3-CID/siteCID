#include "iris_outils.h"

float calcul_min(float tab[], int taille) {
    float min = tab[0];
    for (int i = 1; i < taille; i++) {
        if (tab[i] < min) {
            min = tab[i];
        }
    }
    return min;
}

