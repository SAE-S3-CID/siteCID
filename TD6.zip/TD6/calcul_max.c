#include "iris_outils.h"

float calcul_max(float tab[], int taille) {
    float max = tab[0];
    for (int i = 1; i < taille; i++) {
        if (tab[i] > max) {
            max = tab[i];
        }
    }
    return max;
}
