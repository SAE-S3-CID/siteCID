#include <stdio.h>
#include <stdlib.h>

//Fonction pour calculer la moyenne
float calcul_moyenne(float tab[], int taille);

//Fonction pour calculer la moyenne
float calcul_min(float tab[], int taille);

//Fonction pour calculer la moyenne
float calcul_max(float tab[], int taille);

//Fonction pour afficher les résultats
void affiche_resultats(float moyenne[], float min[], float max[]);
