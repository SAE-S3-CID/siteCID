#include "iris_outils.h"


void affiche_resultats(float moyenne[], float min[], float max[]) {
    printf("Moyenne: %.2f\n", moyenne[0]);
    printf("Minimum: %.2f\n", min[0]);
    printf("Maximum: %.2f\n", max[0]);
}

p
