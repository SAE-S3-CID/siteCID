#include "iris_outils.h"

float calcul_moyenne(float tab[], int taille) {
    float somme = 0;
    for (int i = 0; i < taille; i++) {
        somme += tab[i];
    }
    return somme / taille;
}
